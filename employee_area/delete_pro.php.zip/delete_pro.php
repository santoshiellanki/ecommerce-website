<?php
session_start();
if(!isset($_SESSION['employee_name'])){
echo "<script>window.open('employee_login.php? not_employee = You are not an employee.','_self')</script>";
}
else
{
$con = mysqli_connect("localhost","ellankis1","Kaushik@18","ellankis_DB_Project");
if (mysqli_connect_errno())
{
echo "Failed to connect to MYSQL: " .mysqli_connect_error();
}

 
 if(isset($_GET['delete_pro'])){
 
 $delete_id = $_GET['delete_pro'];
 $delete_pro = "delete from products where product_id='$delete_id'";
 $run_delete = mysqli_query($con,$delete_pro);
  if($run_delete)
  {
  echo "<script>alert('A product has been deleted')</script>";
  echo "<script>window.open('index.php?view_products','_self')</script>";
  }
 
 
 
 }

?>
<?php } ?>